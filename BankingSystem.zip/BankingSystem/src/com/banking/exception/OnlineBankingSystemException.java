package com.banking.exception;

public class OnlineBankingSystemException {
public OnlineBankingSystemException() {
		
	}

	//Constructor with Field
	public OnlineBankingSystemException(String message) {
		
		System.out.println(message);
		
	}
}
