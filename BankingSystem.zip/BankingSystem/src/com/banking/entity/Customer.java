package com.banking.entity;


public class Customer {

}
