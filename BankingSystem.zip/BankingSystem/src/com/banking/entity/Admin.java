package com.banking.entity;

public class Admin {

}
