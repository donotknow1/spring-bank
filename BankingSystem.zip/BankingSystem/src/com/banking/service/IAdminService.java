package com.banking.service;

public interface IAdminService {

}
