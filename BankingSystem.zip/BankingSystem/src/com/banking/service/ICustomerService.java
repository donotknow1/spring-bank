package com.banking.service;

public interface ICustomerService {

}
