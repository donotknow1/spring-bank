package com.banking.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.banking.dao.ICusomerDao;

public class CustomerServiceImpl implements ICustomerService{

	@Autowired
	private ICusomerDao customerDao;
}
