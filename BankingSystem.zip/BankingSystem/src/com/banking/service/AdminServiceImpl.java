package com.banking.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.banking.dao.IAdminDao;

public class AdminServiceImpl implements IAdminService{

	@Autowired
	private IAdminDao adminDao;
}
