package com.banking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.banking.service.IAdminService;


//Admin Controller class
@Controller
public class AdminController {
	
	@Autowired
	private IAdminService adminService;

}
