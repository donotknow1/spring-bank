package com.banking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.banking.service.ICustomerService;


//Account Holder Controller Class
@Controller
public class CustomerController {
	
	@Autowired
	private ICustomerService customerService;

}
