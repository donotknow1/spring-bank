package com.banking.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

public class AdminDao implements IAdminDao{
	
	
	@PersistenceContext
    EntityManager entityManager;
}
