package com.banking.dao;

public interface ICusomerDao {

}
