package com.banking.dao;

public interface IAdminDao {

}
