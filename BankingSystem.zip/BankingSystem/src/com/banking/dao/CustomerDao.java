package com.banking.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

public class CustomerDao implements ICusomerDao{
	
	
	@PersistenceContext
    EntityManager entityManager;
}
